<footer class="footer">
    <div class="container">
        <center><span class="text-muted">Copyright &copy; <?php echo date("Y"); ?> Ramita - Web Pengaduan</span></center>
    </div>
</footer>
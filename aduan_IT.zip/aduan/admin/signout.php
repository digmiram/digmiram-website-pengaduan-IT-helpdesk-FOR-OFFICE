<?php
session_start();
echo "<script>location.href='signin.php'</script>";
session_destroy();
